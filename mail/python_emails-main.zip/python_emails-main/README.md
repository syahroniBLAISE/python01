Scripts for simple text emails and also emails with attachments,
Coded By "The Intrigued Engineer" over a coffee
Thanks For Watching!!!

![thumbnail](https://user-images.githubusercontent.com/109388113/197361269-de973e76-a13c-4fcd-a49f-1e7dc593d651.png)
Video Link:
https://youtu.be/Sddnn6dpqk0
